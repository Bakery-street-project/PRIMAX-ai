import plotly.graph_objects as go
import plotly.express as px
import numpy as np

# Create Enhanced Elohim Shard architecture flowchart using Plotly
# Define node positions for a clean layout
nodes = {
    'User Input': (0.5, 0.9),
    'ElohimShardEnhanced': (0.5, 0.6),
    'SemanticMemorySystem': (0.15, 0.3),
    'NeuralEvolutionEngine': (0.85, 0.3),
    'CreativeResponseGenerator': (0.25, 0.1),
    'ReflectionSystem': (0.75, 0.1),
    'Output/Response': (0.5, 0.05)
}

# Define connections (edges)
edges = [
    ('User Input', 'ElohimShardEnhanced'),
    ('ElohimShardEnhanced', 'SemanticMemorySystem'),
    ('SemanticMemorySystem', 'ElohimShardEnhanced'),
    ('ElohimShardEnhanced', 'CreativeResponseGenerator'),
    ('CreativeResponseGenerator', 'ElohimShardEnhanced'),
    ('ElohimShardEnhanced', 'ReflectionSystem'),
    ('ReflectionSystem', 'ElohimShardEnhanced'),
    ('ElohimShardEnhanced', 'NeuralEvolutionEngine'),
    ('ElohimShardEnhanced', 'Output/Response')
]

# Create figure
fig = go.Figure()

# Add edges
for source, target in edges:
    x0, y0 = nodes[source]
    x1, y1 = nodes[target]
    
    # Add arrow line
    fig.add_trace(go.Scatter(
        x=[x0, x1], y=[y0, y1],
        mode='lines',
        line=dict(color='#333333', width=2),
        showlegend=False,
        hoverinfo='none'
    ))
    
    # Add arrowhead
    dx = x1 - x0
    dy = y1 - y0
    length = np.sqrt(dx**2 + dy**2)
    if length > 0:
        dx_norm = dx / length
        dy_norm = dy / length
        
        # Arrow position (slightly before the target node)
        arrow_x = x1 - dx_norm * 0.08
        arrow_y = y1 - dy_norm * 0.08
        
        fig.add_annotation(
            x=arrow_x, y=arrow_y,
            ax=x0, ay=y0,
            xref='x', yref='y',
            axref='x', ayref='y',
            arrowhead=2,
            arrowsize=1,
            arrowwidth=2,
            arrowcolor='#333333',
            showarrow=True,
            text='',
            bgcolor='rgba(0,0,0,0)'
        )

# Define node details
node_details = {
    'User Input': '',
    'ElohimShardEnhanced': 'Central Orchestrator',
    'SemanticMemorySystem': 'Short-term deque<br>Long-term list<br>Embeddings 64-dim<br>Cosine similarity',
    'NeuralEvolutionEngine': 'Weight matrix<br>Temperature param<br>Momentum<br>Learning rate',
    'CreativeResponseGenerator': 'Base creations list<br>Response templates<br>Novelty calculation<br>Coherence scoring',
    'ReflectionSystem': 'Performance metrics<br>Auto-adjustment<br>Creation history',
    'Output/Response': ''
}

# Define colors for each node type
node_colors = {
    'User Input': '#1FB8CD',
    'ElohimShardEnhanced': '#DB4545',
    'SemanticMemorySystem': '#2E8B57',
    'NeuralEvolutionEngine': '#5D878F',
    'CreativeResponseGenerator': '#D2BA4C',
    'ReflectionSystem': '#B4413C',
    'Output/Response': '#1FB8CD'
}

# Add nodes
for name, (x, y) in nodes.items():
    details = node_details[name]
    full_text = f"<b>{name}</b>"
    if details:
        full_text += f"<br>{details}"
    
    fig.add_trace(go.Scatter(
        x=[x], y=[y],
        mode='markers+text',
        marker=dict(
            size=80 if name == 'ElohimShardEnhanced' else 60,
            color=node_colors[name],
            line=dict(width=2, color='white'),
            symbol='square'
        ),
        text=name,
        textposition="middle center",
        textfont=dict(size=10, color='white'),
        showlegend=False,
        hovertext=full_text,
        hoverinfo='text'
    ))

# Update layout
fig.update_layout(
    title="Enhanced Elohim Shard Architecture",
    showlegend=False,
    xaxis=dict(
        showgrid=False,
        zeroline=False,
        showticklabels=False,
        range=[-0.1, 1.1]
    ),
    yaxis=dict(
        showgrid=False,
        zeroline=False,
        showticklabels=False,
        range=[-0.05, 1.0]
    ),
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)'
)

# Save the chart
fig.write_image("elohim_architecture.png")
fig.write_image("elohim_architecture.svg", format="svg")

print("Enhanced Elohim Shard architecture flowchart created successfully!")