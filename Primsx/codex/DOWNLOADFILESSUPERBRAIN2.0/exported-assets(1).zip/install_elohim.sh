#!/bin/bash
# Elohim Shard - Ubuntu Quick Installation Script
# Run with: bash install_elohim.sh

set -e  # Exit on error

echo "=========================================="
echo "  🌟 Elohim Shard Installation Script"
echo "=========================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Python 3 is installed
echo -e "${BLUE}[1/6] Checking Python installation...${NC}"
if ! command -v python3 &> /dev/null; then
    echo -e "${YELLOW}Python 3 not found. Installing...${NC}"
    sudo apt update
    sudo apt install -y python3-full python3-pip python3-venv
else
    echo -e "${GREEN}✓ Python 3 is installed: $(python3 --version)${NC}"
fi

# Create project directory
echo -e "\n${BLUE}[2/6] Creating project directory...${NC}"
PROJECT_DIR="$HOME/elohim-shard"
mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"
echo -e "${GREEN}✓ Created directory: $PROJECT_DIR${NC}"

# Create virtual environment
echo -e "\n${BLUE}[3/6] Setting up virtual environment...${NC}"
if [ ! -d ".venv" ]; then
    python3 -m venv .venv
    echo -e "${GREEN}✓ Virtual environment created${NC}"
else
    echo -e "${GREEN}✓ Virtual environment already exists${NC}"
fi

# Activate virtual environment
echo -e "\n${BLUE}[4/6] Activating virtual environment...${NC}"
source .venv/bin/activate
echo -e "${GREEN}✓ Virtual environment activated${NC}"

# Upgrade pip
echo -e "\n${BLUE}[5/6] Upgrading pip...${NC}"
pip install --upgrade pip --quiet
echo -e "${GREEN}✓ Pip upgraded to latest version${NC}"

# Install dependencies
echo -e "\n${BLUE}[6/6] Installing dependencies...${NC}"
echo "Installing numpy..."
pip install numpy --quiet
echo -e "${GREEN}✓ NumPy installed${NC}"

# Optional: Install advanced dependencies
read -p "Install optional dependencies for production embeddings? (sentence-transformers) [y/N]: " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Installing sentence-transformers (this may take a few minutes)..."
    pip install sentence-transformers --quiet
    echo -e "${GREEN}✓ Sentence-transformers installed${NC}"
fi

# Create a simple test file
echo -e "\n${BLUE}Creating test script...${NC}"
cat > test_elohim.py << 'EOF'
#!/usr/bin/env python3
"""Quick test script for Elohim Shard"""

import numpy as np
print("✓ NumPy imported successfully")
print(f"  Version: {np.__version__}")

try:
    from sentence_transformers import SentenceTransformer
    print("✓ Sentence-transformers available")
except ImportError:
    print("✓ Basic dependencies ready (sentence-transformers optional)")

print("\n🎉 All dependencies installed successfully!")
print("\nNext steps:")
print("  1. Activate virtual environment: source .venv/bin/activate")
print("  2. Run the enhanced Elohim: python elohim_enhanced.py")
EOF

chmod +x test_elohim.py

# Run test
echo -e "\n${BLUE}Running dependency test...${NC}"
python test_elohim.py

# Create activation helper script
cat > run_elohim.sh << 'EOF'
#!/bin/bash
# Helper script to run Elohim Shard

cd "$(dirname "$0")"
source .venv/bin/activate
python elohim_enhanced.py
EOF

chmod +x run_elohim.sh

# Create README
cat > README.md << 'EOF'
# Elohim Shard - Enhanced AI Agent

## Quick Start

### Activate Virtual Environment
```bash
source .venv/bin/activate
```

### Run the Enhanced Elohim
```bash
python elohim_enhanced.py
```

Or use the helper script:
```bash
./run_elohim.sh
```

### Interactive Commands
- Type your creative prompts
- `status` - View system status
- `temperature [0.1-2.0]` - Adjust creativity level
- `exit` - End session

## Examples

```bash
Forge with me: create an artwork
Forge with me: design a game
Forge with me: temperature 1.5
Forge with me: status
```

## File Structure

- `elohim_enhanced.py` - Main enhanced implementation
- `enhancement-guide.md` - Comprehensive documentation
- `run_elohim.sh` - Helper script to activate venv and run
- `.venv/` - Virtual environment (isolated Python packages)

## Customization

Edit `elohim_enhanced.py` to:
- Adjust memory capacity
- Add custom response templates
- Modify evolution parameters
- Change creativity defaults

See `enhancement-guide.md` for detailed documentation.

## Troubleshooting

**Virtual environment not activating?**
```bash
source .venv/bin/activate
```

**Missing dependencies?**
```bash
pip install numpy
```

**Want to reset?**
```bash
deactivate
rm -rf .venv
bash install_elohim.sh
```

## Next Steps

1. Read `enhancement-guide.md` for full documentation
2. Experiment with different temperature settings
3. Observe self-evolution over multiple interactions
4. Customize response templates to your style

Elohim, Elohim - May your creations ignite! ✨
EOF

# Installation complete
echo ""
echo "=========================================="
echo -e "${GREEN}✨ Installation Complete! ✨${NC}"
echo "=========================================="
echo ""
echo -e "${BLUE}Project Location:${NC} $PROJECT_DIR"
echo ""
echo -e "${BLUE}To get started:${NC}"
echo "  1. cd $PROJECT_DIR"
echo "  2. Place elohim_enhanced.py in this directory"
echo "  3. source .venv/bin/activate"
echo "  4. python elohim_enhanced.py"
echo ""
echo -e "${BLUE}Or use the helper script:${NC}"
echo "  ./run_elohim.sh"
echo ""
echo -e "${GREEN}Files created:${NC}"
echo "  • .venv/ (virtual environment)"
echo "  • test_elohim.py (dependency test)"
echo "  • run_elohim.sh (helper script)"
echo "  • README.md (quick reference)"
echo ""
echo "=========================================="
echo -e "🎨 ${YELLOW}Forge with creativity!${NC} ✨"
echo "=========================================="
