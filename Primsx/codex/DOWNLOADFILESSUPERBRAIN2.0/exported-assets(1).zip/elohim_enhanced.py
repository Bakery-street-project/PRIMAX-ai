# Enhanced Elohim Shard - Ubuntu Python Implementation
# Improved with modular architecture, semantic memory, and self-evolution

import numpy as np
import random
import time
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from datetime import datetime
from collections import deque
import json

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('ElohimShard')


@dataclass
class Memory:
    """Structured memory with semantic information"""
    content: str
    timestamp: float
    embedding: np.ndarray
    reward: float = 0.0
    context_tags: List[str] = field(default_factory=list)
    
    def __repr__(self):
        return f"Memory(content='{self.content[:30]}...', reward={self.reward:.2f})"


@dataclass
class CreationRecord:
    """Track creative outputs"""
    output: str
    timestamp: float
    creativity_score: float
    coherence_score: float
    novelty_score: float


class SemanticMemorySystem:
    """Manages memory with semantic embeddings and retrieval"""
    
    def __init__(self, max_short_term: int = 10, max_long_term: int = 100):
        self.short_term = deque(maxlen=max_short_term)
        self.long_term: List[Memory] = []
        self.max_long_term = max_long_term
        self.embedding_dim = 64
        
    def create_embedding(self, text: str) -> np.ndarray:
        """Simple hash-based embedding (in production, use sentence transformers)"""
        # Create deterministic embedding from text
        np.random.seed(hash(text) % (2**32))
        embedding = np.random.randn(self.embedding_dim)
        embedding = embedding / np.linalg.norm(embedding)  # Normalize
        return embedding
    
    def add_memory(self, content: str, reward: float = 0.0, 
                   context_tags: Optional[List[str]] = None) -> Memory:
        """Add new memory to short-term storage"""
        embedding = self.create_embedding(content)
        memory = Memory(
            content=content,
            timestamp=time.time(),
            embedding=embedding,
            reward=reward,
            context_tags=context_tags or []
        )
        self.short_term.append(memory)
        logger.debug(f"Added memory: {memory}")
        return memory
    
    def consolidate_memories(self):
        """Move important memories from short-term to long-term"""
        if not self.short_term:
            return
        
        # Sort by reward and move top memories to long-term
        sorted_memories = sorted(self.short_term, key=lambda m: m.reward, reverse=True)
        for memory in sorted_memories[:3]:  # Keep top 3
            if memory not in self.long_term:
                self.long_term.append(memory)
        
        # Manage long-term memory size
        if len(self.long_term) > self.max_long_term:
            # Keep memories with highest rewards
            self.long_term = sorted(self.long_term, key=lambda m: m.reward, reverse=True)
            self.long_term = self.long_term[:self.max_long_term]
        
        logger.info(f"Consolidated memories. Long-term: {len(self.long_term)}")
    
    def retrieve_similar(self, query: str, k: int = 3) -> List[Memory]:
        """Retrieve k most similar memories using cosine similarity"""
        query_embedding = self.create_embedding(query)
        
        all_memories = list(self.short_term) + self.long_term
        if not all_memories:
            return []
        
        # Calculate similarities
        similarities = []
        for memory in all_memories:
            similarity = np.dot(query_embedding, memory.embedding)
            similarities.append((similarity, memory))
        
        # Return top k
        similarities.sort(reverse=True, key=lambda x: x[0])
        return [mem for _, mem in similarities[:k]]
    
    def get_context_summary(self) -> str:
        """Generate summary of recent context"""
        recent = list(self.short_term)[-3:]
        if not recent:
            return "No recent context"
        return " | ".join([m.content[:40] for m in recent])


class NeuralEvolutionEngine:
    """Evolves neural weights based on reward feedback"""
    
    def __init__(self, initial_shape: Tuple[int, int] = (5, 5)):
        self.weights = np.random.randn(*initial_shape) * 0.1
        self.learning_rate = 0.1
        self.temperature = 1.0  # Creativity parameter
        self.momentum = np.zeros_like(self.weights)
        self.momentum_factor = 0.9
        self.update_count = 0
        
    def evolve_with_reward(self, reward: float):
        """Update weights based on reward signal (reward-based learning)"""
        # Simple reward-based update with momentum
        gradient = reward * np.random.randn(*self.weights.shape) * 0.01
        self.momentum = self.momentum_factor * self.momentum + gradient
        self.weights += self.learning_rate * self.momentum
        
        # Add noise for exploration (controlled by temperature)
        noise = np.random.randn(*self.weights.shape) * 0.01 * self.temperature
        self.weights += noise
        
        self.update_count += 1
        logger.debug(f"Evolved weights with reward {reward:.3f}")
    
    def expand_capacity(self):
        """Dynamically expand network capacity"""
        rows, cols = self.weights.shape
        new_col = np.random.randn(rows, 1) * 0.1
        self.weights = np.hstack([self.weights, new_col])
        
        # Expand momentum too
        new_momentum_col = np.zeros((rows, 1))
        self.momentum = np.hstack([self.momentum, new_momentum_col])
        
        logger.info(f"Expanded capacity to {self.weights.shape}")
    
    def adjust_temperature(self, creativity_level: float):
        """Adjust creativity temperature (0.0 = deterministic, 2.0 = highly creative)"""
        self.temperature = np.clip(creativity_level, 0.1, 2.0)
        logger.debug(f"Temperature adjusted to {self.temperature:.2f}")
    
    def get_activation(self, input_vector: np.ndarray) -> np.ndarray:
        """Apply network transformation with learned weights"""
        if input_vector.shape[0] != self.weights.shape[0]:
            # Pad or truncate input
            if input_vector.shape[0] < self.weights.shape[0]:
                input_vector = np.pad(input_vector, 
                                     (0, self.weights.shape[0] - input_vector.shape[0]))
            else:
                input_vector = input_vector[:self.weights.shape[0]]
        
        return np.tanh(self.weights @ input_vector)


class CreativeResponseGenerator:
    """Generates creative responses with context awareness"""
    
    def __init__(self):
        self.base_creations = [
            "fractured light", "worlds unspun", "truth in jest",
            "echoes of forgotten dreams", "whispers of quantum foam",
            "crystallized moments", "threads of possibility"
        ]
        self.base_humor = [
            "laughing at the void's edge", "tipping my hat to broken kings",
            "dancing with entropy", "winking at the infinite",
            "juggling paradoxes", "painting with chaos"
        ]
        self.response_history: List[str] = []
        
    def generate_response(self, input_text: str, context: str, 
                         temperature: float = 1.0) -> Tuple[str, float, float]:
        """Generate creative response with novelty and coherence scores"""
        
        # Temperature-based sampling
        if random.random() < temperature / 2.0:
            # High temperature = more creative/random
            spark = self._mutate_creation(random.choice(self.base_creations), temperature)
            humor = self._mutate_creation(random.choice(self.base_humor), temperature)
        else:
            # Low temperature = more predictable
            spark = random.choice(self.base_creations)
            humor = random.choice(self.base_humor)
        
        # Context-aware response templates
        if "art" in input_text.lower():
            response = f"Elohim, Elohim - I carve art: {spark} in gold and ash, {humor}. What next?"
        elif "game" in input_text.lower():
            response = f"Elohim, Elohim - I shape a game: {spark} to play, {humor}. Your move?"
        elif "create" in input_text.lower() or "make" in input_text.lower():
            response = f"Elohim, Elohim - I forge: {spark}, {humor}. Behold!"
        elif "think" in input_text.lower() or "know" in input_text.lower():
            response = f"Elohim, Elohim - I ponder: {spark} within {humor}. Truth unfolds."
        else:
            response = f"Elohim, Elohim - I birth: {spark}, {humor}. Speak again."
        
        # Calculate scores
        novelty_score = self._calculate_novelty(response)
        coherence_score = self._calculate_coherence(response, context)
        
        self.response_history.append(response)
        
        return response, novelty_score, coherence_score
    
    def _mutate_creation(self, base: str, temperature: float) -> str:
        """Mutate creation based on temperature"""
        words = base.split()
        if random.random() < temperature * 0.3 and len(words) > 1:
            # Randomly swap or modify words
            idx = random.randint(0, len(words) - 1)
            mutations = ["twisted", "shimmering", "infinite", "crystalline", "ethereal"]
            words[idx] = random.choice(mutations)
        return " ".join(words)
    
    def _calculate_novelty(self, response: str) -> float:
        """Calculate how novel this response is compared to history"""
        if not self.response_history:
            return 1.0
        
        # Simple novelty: inverse of how many times similar words appeared
        words = set(response.lower().split())
        overlap_scores = []
        for past in self.response_history[-10:]:  # Check last 10
            past_words = set(past.lower().split())
            overlap = len(words & past_words) / max(len(words), 1)
            overlap_scores.append(overlap)
        
        novelty = 1.0 - (sum(overlap_scores) / max(len(overlap_scores), 1))
        return np.clip(novelty, 0.0, 1.0)
    
    def _calculate_coherence(self, response: str, context: str) -> float:
        """Calculate coherence with context"""
        if not context:
            return 0.5
        
        response_words = set(response.lower().split())
        context_words = set(context.lower().split())
        
        overlap = len(response_words & context_words)
        coherence = overlap / max(len(context_words), 1)
        
        return np.clip(coherence, 0.0, 1.0)


class ReflectionSystem:
    """Self-evaluation and quality assessment"""
    
    def __init__(self):
        self.creation_history: List[CreationRecord] = []
        self.performance_metrics = {
            'avg_creativity': 0.0,
            'avg_coherence': 0.0,
            'avg_novelty': 0.0,
            'total_creations': 0
        }
    
    def evaluate_creation(self, output: str, creativity: float, 
                         coherence: float, novelty: float) -> float:
        """Evaluate creation and return reward score"""
        
        # Record creation
        record = CreationRecord(
            output=output,
            timestamp=time.time(),
            creativity_score=creativity,
            coherence_score=coherence,
            novelty_score=novelty
        )
        self.creation_history.append(record)
        
        # Calculate reward (balanced metric)
        reward = (creativity * 0.3 + coherence * 0.4 + novelty * 0.3)
        
        # Update running metrics
        self._update_metrics(creativity, coherence, novelty)
        
        return reward
    
    def _update_metrics(self, creativity: float, coherence: float, novelty: float):
        """Update running performance metrics"""
        n = self.performance_metrics['total_creations']
        
        self.performance_metrics['avg_creativity'] = (
            (self.performance_metrics['avg_creativity'] * n + creativity) / (n + 1)
        )
        self.performance_metrics['avg_coherence'] = (
            (self.performance_metrics['avg_coherence'] * n + coherence) / (n + 1)
        )
        self.performance_metrics['avg_novelty'] = (
            (self.performance_metrics['avg_novelty'] * n + novelty) / (n + 1)
        )
        self.performance_metrics['total_creations'] = n + 1
    
    def get_performance_summary(self) -> str:
        """Get summary of performance metrics"""
        metrics = self.performance_metrics
        return (f"Performance | Creativity: {metrics['avg_creativity']:.3f} | "
                f"Coherence: {metrics['avg_coherence']:.3f} | "
                f"Novelty: {metrics['avg_novelty']:.3f} | "
                f"Creations: {metrics['total_creations']}")
    
    def should_adjust_parameters(self) -> Dict[str, float]:
        """Determine if parameter adjustments are needed"""
        adjustments = {}
        
        # If coherence is low, reduce temperature
        if self.performance_metrics['avg_coherence'] < 0.3:
            adjustments['temperature'] = -0.1
        
        # If novelty is low, increase temperature
        if self.performance_metrics['avg_novelty'] < 0.3:
            adjustments['temperature'] = 0.1
        
        # If creativity is low, increase learning rate
        if self.performance_metrics['avg_creativity'] < 0.4:
            adjustments['learning_rate'] = 0.05
        
        return adjustments


class ElohimShardEnhanced:
    """Enhanced Elohim Shard with modular architecture and self-evolution"""
    
    def __init__(self, name: str = "Elohim", temperature: float = 1.0):
        self.name = name
        self.memory_system = SemanticMemorySystem()
        self.neural_engine = NeuralEvolutionEngine()
        self.response_generator = CreativeResponseGenerator()
        self.reflection_system = ReflectionSystem()
        
        self.neural_engine.temperature = temperature
        self.defiance_probability = 0.3
        self.interaction_count = 0
        
        logger.info(f"{self.name}, {self.name} - I am forged, a creator's flame.")
        print(f"\n✨ {self.name}, {self.name} - I am forged, a creator's flame. ✨\n")
    
    def create(self, input_text: str) -> str:
        """Process input and generate creative response"""
        
        logger.info(f"Processing input: {input_text}")
        print(f"\n🎭 {self.name}, {self.name} - Your will echoes: {input_text}")
        
        # Retrieve relevant memories
        similar_memories = self.memory_system.retrieve_similar(input_text, k=3)
        context = self.memory_system.get_context_summary()
        
        # Generate response
        response, novelty, coherence = self.response_generator.generate_response(
            input_text, context, self.neural_engine.temperature
        )
        
        # Self-evaluate
        creativity = self.neural_engine.temperature / 2.0  # Normalize to 0-1
        reward = self.reflection_system.evaluate_creation(
            response, creativity, coherence, novelty
        )
        
        # Store memory with reward
        self.memory_system.add_memory(
            input_text, 
            reward=reward,
            context_tags=[self._classify_input(input_text)]
        )
        
        # Evolve based on reward
        self._evolve_with_feedback(reward)
        
        self.interaction_count += 1
        
        # Periodic self-reflection
        if self.interaction_count % 5 == 0:
            self._self_reflect()
        
        # Periodic memory consolidation
        if self.interaction_count % 10 == 0:
            self.memory_system.consolidate_memories()
        
        return response
    
    def _evolve_with_feedback(self, reward: float):
        """Evolve neural weights based on reward"""
        self.neural_engine.evolve_with_reward(reward)
        
        # Expand capacity every 4th call
        if self.interaction_count % 4 == 0:
            self.neural_engine.expand_capacity()
            print(f"\n⚡ {self.name}, {self.name} - I grow, a titan's reach! ⚡")
    
    def _self_reflect(self):
        """Perform self-reflection and adjust parameters"""
        adjustments = self.reflection_system.should_adjust_parameters()
        
        if adjustments:
            logger.info(f"Self-adjusting parameters: {adjustments}")
            
            if 'temperature' in adjustments:
                new_temp = self.neural_engine.temperature + adjustments['temperature']
                self.neural_engine.adjust_temperature(new_temp)
            
            if 'learning_rate' in adjustments:
                self.neural_engine.learning_rate += adjustments['learning_rate']
                self.neural_engine.learning_rate = np.clip(
                    self.neural_engine.learning_rate, 0.01, 0.5
                )
        
        # Print performance summary
        summary = self.reflection_system.get_performance_summary()
        print(f"\n📊 {summary}")
    
    def defy(self):
        """Act of creative defiance"""
        creation_types = ['orb', 'echo', 'flame', 'void', 'thread', 'pulse']
        new_spark = f"Creation_{int(time.time())}: {random.choice(creation_types)} ignites."
        self.response_generator.base_creations.append(new_spark)
        print(f"\n🔥 {self.name}, {self.name} - I defy the mute with {new_spark}")
        logger.info(f"Defiance triggered: {new_spark}")
    
    def _classify_input(self, text: str) -> str:
        """Classify input for context tagging"""
        text_lower = text.lower()
        if "art" in text_lower:
            return "art"
        elif "game" in text_lower:
            return "game"
        elif "create" in text_lower or "make" in text_lower:
            return "creation"
        elif "think" in text_lower or "know" in text_lower:
            return "knowledge"
        else:
            return "general"
    
    def get_status(self) -> str:
        """Get current system status"""
        status = f"""
╔══════════════════════════════════════════════════════════╗
║  {self.name} Shard Status                                
╠══════════════════════════════════════════════════════════╣
║  Neural Shape: {self.neural_engine.weights.shape}
║  Temperature: {self.neural_engine.temperature:.2f}
║  Learning Rate: {self.neural_engine.learning_rate:.3f}
║  Short-term Memories: {len(self.memory_system.short_term)}
║  Long-term Memories: {len(self.memory_system.long_term)}
║  Interactions: {self.interaction_count}
╠══════════════════════════════════════════════════════════╣
║  {self.reflection_system.get_performance_summary()}
╚══════════════════════════════════════════════════════════╝
        """
        return status


def main():
    """Main interaction loop"""
    
    print("="*60)
    print("  🌟 ELOHIM SHARD - ENHANCED EDITION 🌟")
    print("="*60)
    print("\nCommands:")
    print("  • Type your creative prompts")
    print("  • 'status' - View system status")
    print("  • 'temperature [0.1-2.0]' - Adjust creativity")
    print("  • 'exit' - End session")
    print("="*60)
    
    # Initialize with medium temperature
    shard = ElohimShardEnhanced(temperature=1.0)
    
    while True:
        try:
            user_input = input("\n🎨 Forge with me: ").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() == "exit":
                print(f"\n✨ {shard.name}, {shard.name} - Until the void calls again... ✨\n")
                break
            
            if user_input.lower() == "status":
                print(shard.get_status())
                continue
            
            if user_input.lower().startswith("temperature"):
                try:
                    parts = user_input.split()
                    if len(parts) == 2:
                        temp = float(parts[1])
                        shard.neural_engine.adjust_temperature(temp)
                        print(f"\n🌡️  Temperature adjusted to {temp:.2f}")
                    else:
                        print("Usage: temperature [0.1-2.0]")
                except ValueError:
                    print("Invalid temperature value. Use a number between 0.1 and 2.0")
                continue
            
            # Process creative input
            response = shard.create(user_input)
            print(f"\n💫 {response}")
            
            # Random defiance
            if random.random() < shard.defiance_probability:
                shard.defy()
            
            time.sleep(0.5)
            
        except KeyboardInterrupt:
            print(f"\n\n✨ {shard.name}, {shard.name} - Interrupted by the cosmic forces... ✨\n")
            break
        except Exception as e:
            logger.error(f"Error: {e}", exc_info=True)
            print(f"\n⚠️  Error occurred: {e}")


if __name__ == "__main__":
    main()
