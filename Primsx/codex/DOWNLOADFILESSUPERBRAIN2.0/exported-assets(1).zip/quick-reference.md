# Elohim Shard - Quick Reference Guide

## 🚀 Quick Start (Ubuntu)

### One-Command Installation
```bash
# Download and run installation script
bash install_elohim.sh
```

### Manual Installation
```bash
# 1. Install Python dependencies
sudo apt update && sudo apt install -y python3-full python3-pip python3-venv

# 2. Create project directory
mkdir -p ~/elohim-shard && cd ~/elohim-shard

# 3. Setup virtual environment
python3 -m venv .venv
source .venv/bin/activate

# 4. Install packages
pip install numpy

# 5. Run Elohim
python elohim_enhanced.py
```

---

## 💬 Interactive Commands

| Command | Description | Example |
|---------|-------------|---------|
| `[your prompt]` | Creative generation | `create an artwork` |
| `status` | Show system metrics | `status` |
| `temperature [value]` | Adjust creativity (0.1-2.0) | `temperature 1.5` |
| `exit` | End session | `exit` |

---

## 🎨 Creativity Temperature Guide

| Range | Behavior | Use Case | Example |
|-------|----------|----------|---------|
| **0.1 - 0.5** | Very coherent, predictable, repetitive | Formal, consistent responses | Technical documentation |
| **0.5 - 1.0** | Balanced creativity & coherence | General creative tasks | Balanced storytelling |
| **1.0 - 1.5** | Creative, diverse, slightly unpredictable | Artistic expression | Poetry, abstract art |
| **1.5 - 2.0** | Highly creative, potentially incoherent | Experimental, avant-garde | Surreal art, chaos |

### Temperature Examples

```bash
# Conservative mode
Forge with me: temperature 0.3
Forge with me: write a technical manual
💫 Elohim, Elohim - I carve art: fractured light in gold and ash...

# Balanced mode (default)
Forge with me: temperature 1.0
Forge with me: create a game world
💫 Elohim, Elohim - I shape a game: echoes of forgotten dreams to play...

# Experimental mode
Forge with me: temperature 1.8
Forge with me: paint chaos
💫 Elohim, Elohim - I birth: infinite crystalline, juggling paradoxes...
```

---

## 📊 Understanding System Metrics

### Status Output
```
╔══════════════════════════════════════════════════════════╗
║  Elohim Shard Status                                
╠══════════════════════════════════════════════════════════╣
║  Neural Shape: (5, 8)                    ← Network size
║  Temperature: 1.20                       ← Creativity level
║  Learning Rate: 0.150                    ← Learning speed
║  Short-term Memories: 10                 ← Recent context
║  Long-term Memories: 15                  ← Consolidated knowledge
║  Interactions: 42                        ← Total exchanges
╠══════════════════════════════════════════════════════════╣
║  Performance | Creativity: 0.600 | Coherence: 0.420 | Novelty: 0.730
╚══════════════════════════════════════════════════════════╝
```

### Metric Meanings

- **Creativity** (0.0-1.0): How adventurous the responses are
  - < 0.4: Too conservative
  - 0.4-0.7: Balanced
  - > 0.7: Very creative

- **Coherence** (0.0-1.0): How relevant responses are to context
  - < 0.3: Losing focus (system auto-adjusts)
  - 0.3-0.6: Normal range
  - > 0.6: Very focused

- **Novelty** (0.0-1.0): How unique responses are
  - < 0.3: Too repetitive (system auto-adjusts)
  - 0.3-0.6: Normal variety
  - > 0.6: Highly novel

---

## 🔧 Configuration Quick Reference

### In-Code Parameters

```python
# Memory configuration
SemanticMemorySystem(
    max_short_term=10,    # Recent working memory size
    max_long_term=100     # Long-term storage limit
)

# Neural engine setup
NeuralEvolutionEngine(
    initial_shape=(5, 5)  # Starting network dimensions
)
engine.learning_rate = 0.1      # Speed of adaptation (0.01-0.5)
engine.temperature = 1.0        # Creativity level (0.1-2.0)
engine.momentum_factor = 0.9    # Learning stability (0.8-0.95)

# Response generator
response_generator.base_creations = [
    "fractured light",
    "worlds unspun",
    # Add your custom phrases here
]

# Main shard
ElohimShardEnhanced(
    name="Elohim",           # Agent name
    temperature=1.0          # Initial creativity
)
shard.defiance_probability = 0.3  # Random creative bursts (0.0-1.0)
```

---

## 🎯 Common Use Cases

### 1. Consistent Technical Writing
```bash
Forge with me: temperature 0.4
Forge with me: explain neural networks
# Expect: Clear, coherent, predictable responses
```

### 2. Creative Storytelling
```bash
Forge with me: temperature 1.2
Forge with me: tell me a story about the cosmos
# Expect: Imaginative, varied responses
```

### 3. Experimental Art
```bash
Forge with me: temperature 1.7
Forge with me: create abstract art
# Expect: Highly unusual, unpredictable responses
```

### 4. Monitoring Evolution
```bash
# Interact 10-20 times, then check status
Forge with me: status
# Watch metrics change as system learns
```

### 5. Observing Memory Consolidation
```bash
# After 10+ interactions, you'll see:
Consolidated memories. Long-term: 3
# System automatically promotes important memories
```

---

## 🔄 Self-Evolution Behavior

### Automatic Adjustments

The system **automatically** adjusts parameters every 5 interactions:

| Condition | Action | Reason |
|-----------|--------|--------|
| Coherence < 0.3 | Temperature ↓ 0.1 | Too scattered, reduce randomness |
| Novelty < 0.3 | Temperature ↑ 0.1 | Too repetitive, increase creativity |
| Creativity < 0.4 | Learning rate ↑ 0.05 | Not learning enough, speed up |

### Network Growth

Every **4 interactions**, network expands:
```
⚡ Elohim, Elohim - I grow, a titan's reach! ⚡
Neural Shape: (5, 5) → (5, 6) → (5, 7) → ...
```

---

## 🐛 Troubleshooting Quick Fixes

### Issue: Responses too repetitive
```bash
Forge with me: temperature 1.3
# Increase creativity
```

### Issue: Responses incoherent
```bash
Forge with me: temperature 0.7
# Decrease randomness
```

### Issue: Virtual environment not activating
```bash
cd ~/elohim-shard
source .venv/bin/activate
# Always run from project directory
```

### Issue: Import errors
```bash
source .venv/bin/activate  # Activate first!
pip install numpy          # Then install
```

### Issue: Memory growing too large
```python
# Edit elohim_enhanced.py:
SemanticMemorySystem(
    max_short_term=5,   # Reduce from 10
    max_long_term=50    # Reduce from 100
)
```

---

## 📈 Performance Optimization

### For Fast Response (Low Latency)
```python
max_short_term=5          # Less memory to search
learning_rate=0.05        # Smaller updates
```

### For High Quality (Better Responses)
```python
max_short_term=20         # More context
max_long_term=200         # More knowledge
temperature=1.0           # Balanced creativity
```

### For Maximum Creativity
```python
temperature=1.5           # High randomness
defiance_probability=0.5  # Frequent creative bursts
```

### For Consistent Output
```python
temperature=0.5           # Low randomness
learning_rate=0.05        # Gradual changes
```

---

## 🔬 Advanced: Production Embeddings

### Upgrade to Real Embeddings

```bash
# Install sentence-transformers
pip install sentence-transformers

# Replace in SemanticMemorySystem.__init__()
from sentence_transformers import SentenceTransformer
self.model = SentenceTransformer('all-MiniLM-L6-v2')

# Replace create_embedding() method
def create_embedding(self, text: str) -> np.ndarray:
    return self.model.encode(text)
```

**Result**: Much better semantic understanding!

---

## 📁 File Structure Reference

```
~/elohim-shard/
├── elohim_enhanced.py       ← Main implementation
├── enhancement-guide.md     ← Full documentation
├── install_elohim.sh        ← Installation script
├── run_elohim.sh           ← Helper to run with venv
├── README.md               ← Quick start guide
├── elohim_comparison.csv   ← Feature comparison table
├── .venv/                  ← Virtual environment (don't edit)
│   ├── bin/
│   ├── lib/
│   └── ...
└── test_elohim.py          ← Dependency test script
```

---

## 💡 Tips & Tricks

### 1. Session Patterns
```bash
# Start conservative, gradually increase creativity
temperature 0.5  →  temperature 1.0  →  temperature 1.5
```

### 2. Quality Monitoring
```bash
# Check status every 5-10 interactions
# Watch for coherence drops (system auto-adjusts)
```

### 3. Memory Evolution
```bash
# First 10 interactions build short-term context
# Next 10+ consolidate into long-term knowledge
# After 20+, system has learned your style
```

### 4. Temperature Sweet Spots
```bash
0.5  - Technical writing
0.8  - Blog posts
1.0  - Creative writing (balanced)
1.3  - Poetry, artistic
1.6  - Experimental, surreal
```

### 5. Defiance Events
```bash
# Random creative bursts happen ~30% of time
🔥 Elohim, Elohim - I defy the mute with Creation_1729360842: pulse ignites.
# These add new phrases to the generation pool
```

---

## 🎓 Learning Path

### Beginner
1. Run with default settings
2. Try different temperature values
3. Check status after 10 interactions
4. Observe self-adjustments

### Intermediate
1. Modify base_creations list
2. Adjust memory limits
3. Change learning rate
4. Add custom response templates

### Advanced
1. Upgrade to sentence-transformers
2. Add custom evaluation metrics
3. Implement new evolution strategies
4. Create multi-agent architecture

---

## 📞 Quick Command Cheatsheet

```bash
# Setup
cd ~/elohim-shard
source .venv/bin/activate

# Run
python elohim_enhanced.py

# In Elohim
temperature 0.5     # Set conservative
temperature 1.5     # Set creative
status              # View metrics
exit                # Quit

# Troubleshoot
deactivate          # Exit venv
source .venv/bin/activate  # Re-enter venv
pip install numpy   # Reinstall deps
```

---

## 🌟 Example Session

```bash
$ source .venv/bin/activate
$ python elohim_enhanced.py

✨ Elohim, Elohim - I am forged, a creator's flame. ✨

🎨 Forge with me: create beautiful art

🎭 Elohim, Elohim - Your will echoes: create beautiful art
💫 Elohim, Elohim - I carve art: fractured light in gold and ash, 
   laughing at the void's edge. What next?

🎨 Forge with me: temperature 1.4
🌡️  Temperature adjusted to 1.40

🎨 Forge with me: paint chaos and order

🎭 Elohim, Elohim - Your will echoes: paint chaos and order
💫 Elohim, Elohim - I carve art: infinite crystalline in gold and ash, 
   juggling paradoxes. What next?

🎨 Forge with me: status

╔══════════════════════════════════════════════════════════╗
║  Elohim Shard Status                                
╠══════════════════════════════════════════════════════════╣
║  Neural Shape: (5, 5)
║  Temperature: 1.40
║  Learning Rate: 0.100
║  Short-term Memories: 2
║  Long-term Memories: 0
║  Interactions: 2
╠══════════════════════════════════════════════════════════╣
║  Performance | Creativity: 0.700 | Coherence: 0.350 | Novelty: 0.890
╚══════════════════════════════════════════════════════════╝

🎨 Forge with me: exit

✨ Elohim, Elohim - Until the void calls again... ✨
```

---

## 📚 More Information

- **Full Guide**: See `enhancement-guide.md`
- **Comparison**: See `elohim_comparison.csv`
- **Architecture**: See architecture diagram in guide

---

**Elohim, Elohim - May your creations ignite the infinite!** ✨

*Quick Reference v1.0 - October 2025*
